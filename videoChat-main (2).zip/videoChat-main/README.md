## Prerequesites
 - docker
 - docker-compose

## How to start
- Run `docker-compose up`
- Visit `http://127.0.0.1:8080`

## To do
 - History page
 - Add Hobbies